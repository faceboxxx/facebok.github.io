<?php
$gifan = 'ryandpratama2007@gmail.com'; // Masukin email kamu disini
?>